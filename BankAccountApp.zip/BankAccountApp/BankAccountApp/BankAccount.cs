﻿using System;
using System.Text.RegularExpressions; 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountApp
{
    public class BankAccount
    {
        public string Owner { get; set; }
        public Guid AccountNumber { get; set; }
        public decimal Balance { get; private set; }

        public BankAccount(string owner)
        {
            Owner = owner;
            AccountNumber = Guid.NewGuid();
            Balance = 0;
        }

        public string Deposit(decimal amount)
        {
            if (amount <= 0)
                return "You can not deposit R" + amount;
            if (amount > 20000)
                return "You can not deposit more than R20,000 at a time.";
            Balance += amount;
            return "Deposit successful.";
        }
        public string Withdraw(decimal amount)
        {
            if (amount <= 0)
                return "You can not withdraw R" + amount;
            if (amount > Balance)
                return "You dont have enough money to withdraw R" + amount;
            Balance -= amount;
            return "withdraw successful.";
        }
    }
}
