﻿namespace BankAccountApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            AmountNum = new NumericUpDown();
            BankAccountGrid = new DataGridView();
            CreateAccountBtn = new Button();
            Owner = new TextBox();
            DepositBtn = new Button();
            WithDrawBtn = new Button();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)AmountNum).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BankAccountGrid).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Transparent;
            label2.Location = new Point(22, 433);
            label2.Name = "label2";
            label2.Size = new Size(93, 28);
            label2.TabIndex = 1;
            label2.Text = "Amount:";
            // 
            // AmountNum
            // 
            AmountNum.Location = new Point(140, 433);
            AmountNum.Maximum = new decimal(new int[] { 1410065407, 2, 0, 0 });
            AmountNum.Minimum = new decimal(new int[] { 1410065407, 2, 0, int.MinValue });
            AmountNum.Name = "AmountNum";
            AmountNum.Size = new Size(169, 27);
            AmountNum.TabIndex = 2;
            // 
            // BankAccountGrid
            // 
            BankAccountGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            BankAccountGrid.BackgroundColor = Color.DimGray;
            BankAccountGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            BankAccountGrid.Location = new Point(369, 31);
            BankAccountGrid.Name = "BankAccountGrid";
            BankAccountGrid.RowHeadersWidth = 51;
            BankAccountGrid.Size = new Size(582, 330);
            BankAccountGrid.TabIndex = 3;
            // 
            // CreateAccountBtn
            // 
            CreateAccountBtn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateAccountBtn.ForeColor = Color.DarkSlateGray;
            CreateAccountBtn.Location = new Point(140, 199);
            CreateAccountBtn.Name = "CreateAccountBtn";
            CreateAccountBtn.Size = new Size(206, 56);
            CreateAccountBtn.TabIndex = 4;
            CreateAccountBtn.Text = "Create Account";
            CreateAccountBtn.UseVisualStyleBackColor = true;
            CreateAccountBtn.Click += CreateAccountBtn_Click;
            // 
            // Owner
            // 
            Owner.Location = new Point(140, 125);
            Owner.Name = "Owner";
            Owner.Size = new Size(205, 27);
            Owner.TabIndex = 5;
            // 
            // DepositBtn
            // 
            DepositBtn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DepositBtn.ForeColor = Color.DarkSlateGray;
            DepositBtn.Location = new Point(369, 444);
            DepositBtn.Name = "DepositBtn";
            DepositBtn.Size = new Size(241, 64);
            DepositBtn.TabIndex = 6;
            DepositBtn.Text = "Deposit";
            DepositBtn.UseVisualStyleBackColor = true;
            DepositBtn.Click += DepositBtn_Click;
            // 
            // WithDrawBtn
            // 
            WithDrawBtn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            WithDrawBtn.ForeColor = Color.DarkSlateGray;
            WithDrawBtn.Location = new Point(669, 444);
            WithDrawBtn.Name = "WithDrawBtn";
            WithDrawBtn.Size = new Size(235, 64);
            WithDrawBtn.TabIndex = 7;
            WithDrawBtn.Text = "Withdraw";
            WithDrawBtn.UseVisualStyleBackColor = true;
            WithDrawBtn.Click += WithDrawBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Transparent;
            label1.Location = new Point(35, 121);
            label1.Name = "label1";
            label1.Size = new Size(80, 28);
            label1.TabIndex = 8;
            label1.Text = "Owner:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.Transparent;
            label3.Location = new Point(35, 62);
            label3.Name = "label3";
            label3.Size = new Size(271, 20);
            label3.TabIndex = 10;
            label3.Text = "Encrypted Financial Command Center";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.FloralWhite;
            label4.Location = new Point(102, 31);
            label4.Name = "label4";
            label4.Size = new Size(128, 20);
            label4.TabIndex = 10;
            label4.Text = "👁️NEXUX GATE ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(789, 542);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 10;
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.Transparent;
            label6.Location = new Point(515, 559);
            label6.Name = "label6";
            label6.Size = new Size(434, 20);
            label6.TabIndex = 11;
            label6.Text = "📶Connection Status: Secure | Encrypted | Session ID: [NGR]";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.ForeColor = Color.Transparent;
            label7.Location = new Point(3, 559);
            label7.Name = "label7";
            label7.Size = new Size(31, 20);
            label7.TabIndex = 12;
            label7.Text = "👁️";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSlateGray;
            ClientSize = new Size(976, 588);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(WithDrawBtn);
            Controls.Add(DepositBtn);
            Controls.Add(Owner);
            Controls.Add(CreateAccountBtn);
            Controls.Add(BankAccountGrid);
            Controls.Add(AmountNum);
            Controls.Add(label2);
            Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ActiveCaptionText;
            Name = "Form1";
            Text = "👁️Nexus Reserve";
            ((System.ComponentModel.ISupportInitialize)AmountNum).EndInit();
            ((System.ComponentModel.ISupportInitialize)BankAccountGrid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label2;
        private NumericUpDown AmountNum;
        private DataGridView BankAccountGrid;
        private Button CreateAccountBtn;
        private TextBox Owner;
        private Button DepositBtn;
        private Button WithDrawBtn;
        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
    }
}
