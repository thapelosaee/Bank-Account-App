using System.Drawing.Text;

namespace BankAccountApp
{
    public partial class Form1 : Form
    {
        List<BankAccount> BankAccounts = new List<BankAccount>();
        public Form1()
        {
            InitializeComponent();

        }

        private void CreateAccountBtn_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(Owner.Text))
            {
                MessageBox.Show("Please enter a valid owner name.");
                return;
            }
            BankAccount bankAccount = new BankAccount(Owner.Text);
            BankAccounts.Add(bankAccount);

            RefreshGrid();
            Owner.Text = string.Empty; // Clear the input after creating the account
        }
        private void RefreshGrid()
        {
            BankAccountGrid.DataSource = null; // Reset the data source to refresh the grid
            BankAccountGrid.DataSource = BankAccounts;
        }

        private void DepositBtn_Click(object sender, EventArgs e)
        {
            if (BankAccountGrid.SelectedRows.Count == 1)
            {
                BankAccount selectedBankAccount = BankAccountGrid.SelectedRows[0].DataBoundItem as BankAccount;
                string message = selectedBankAccount.Deposit(AmountNum.Value);
                RefreshGrid();
                AmountNum.Value = 0; // Clear the amount after deposit
                MessageBox.Show(message);
            }
            {

            }
        }

        private void WithDrawBtn_Click(object sender, EventArgs e)
        {
            if (BankAccountGrid.SelectedRows.Count == 1)
            {
                BankAccount selectedBankAccount = BankAccountGrid.SelectedRows[0].DataBoundItem as BankAccount;

                string message = selectedBankAccount.Withdraw(AmountNum.Value);
                RefreshGrid();
                AmountNum.Value = 0; // Clear the amount after deposit
                MessageBox.Show(message);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}