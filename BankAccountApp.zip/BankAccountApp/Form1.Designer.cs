﻿namespace BankAccountApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            AmountNum = new Label();
            OwnerTxt = new TextBox();
            numericUpDown1 = new NumericUpDown();
            BankAccountGrid = new DataGridView();
            DepositBtn = new Button();
            WithdrawBtn = new Button();
            CreateAccBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BankAccountGrid).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(22, 42);
            label1.Name = "label1";
            label1.Size = new Size(81, 31);
            label1.TabIndex = 0;
            label1.Text = "Owner";
            // 
            // AmountNum
            // 
            AmountNum.AutoSize = true;
            AmountNum.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            AmountNum.Location = new Point(22, 454);
            AmountNum.Name = "AmountNum";
            AmountNum.Size = new Size(96, 31);
            AmountNum.TabIndex = 1;
            AmountNum.Text = "Amount";
            // 
            // OwnerTxt
            // 
            OwnerTxt.Location = new Point(128, 48);
            OwnerTxt.Name = "OwnerTxt";
            OwnerTxt.Size = new Size(260, 27);
            OwnerTxt.TabIndex = 2;
            OwnerTxt.TextChanged += new EventHandler(OwnerTxt_TextChanged);

            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(148, 461);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(260, 27);
            numericUpDown1.TabIndex = 3;
            numericUpDown1.ValueChanged += numericUpDown1_ValueChanged;
            // 
            // BankAccountGrid
            // 
            BankAccountGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            BankAccountGrid.Location = new Point(407, 48);
            BankAccountGrid.Name = "BankAccountGrid";
            BankAccountGrid.RowHeadersWidth = 51;
            BankAccountGrid.Size = new Size(484, 356);
            BankAccountGrid.TabIndex = 4;
            // 
            // DepositBtn
            // 
            DepositBtn.Location = new Point(452, 426);
            DepositBtn.Name = "DepositBtn";
            DepositBtn.Size = new Size(167, 59);
            DepositBtn.TabIndex = 5;
            DepositBtn.Text = "Deposit";
            DepositBtn.UseVisualStyleBackColor = true;
            // 
            // WithdrawBtn
            // 
            WithdrawBtn.Location = new Point(726, 426);
            WithdrawBtn.Name = "WithdrawBtn";
            WithdrawBtn.Size = new Size(170, 59);
            WithdrawBtn.TabIndex = 6;
            WithdrawBtn.Text = "Withdraw";
            WithdrawBtn.UseVisualStyleBackColor = true;
            // 
            // CreateAccBtn
            // 
            CreateAccBtn.Location = new Point(128, 93);
            CreateAccBtn.Name = "CreateAccBtn";
            CreateAccBtn.Size = new Size(260, 54);
            CreateAccBtn.TabIndex = 7;
            CreateAccBtn.Text = "Create Acccount";
            CreateAccBtn.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(922, 589);
            Controls.Add(CreateAccBtn);
            Controls.Add(WithdrawBtn);
            Controls.Add(DepositBtn);
            Controls.Add(BankAccountGrid);
            Controls.Add(numericUpDown1);
            Controls.Add(OwnerTxt);
            Controls.Add(AmountNum);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)BankAccountGrid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion      

        private Label label1;
        private Label AmountNum;
        private TextBox OwnerTxt;
        private NumericUpDown numericUpDown1;
        private DataGridView BankAccountGrid;
        private Button DepositBtn;
        private Button WithdrawBtn;
        private Button CreateAccBtn;
    }
}
